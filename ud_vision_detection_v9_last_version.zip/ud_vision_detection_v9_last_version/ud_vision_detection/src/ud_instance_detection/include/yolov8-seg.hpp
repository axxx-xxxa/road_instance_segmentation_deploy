#pragma once

#ifndef SEGMENT_SIMPLE_YOLOV8_SEG_HPP
#define SEGMENT_SIMPLE_YOLOV8_SEG_HPP
#include "NvInferPlugin.h"
#include "common.hpp"
#include <fstream>
#include <utils.hpp>
#include <Eigen/Core>
#include <Eigen/Dense>

// @ InsParams :its default params , no need to change
class InsParams {
public:
  int      topk         = 100;
  int      seg_h        = 160;
  int      seg_w        = 160;
  int      seg_channels = 32;
  float    score_thres  = 0.25f;
  float    iou_thres    = 0.65f;
  cv::Size size         = cv::Size{1280, 1280};
  std::vector<cv::Scalar> detect_colors;
  std::vector<cv::Scalar> class_colors;
  std::map<int, std::string> class_labels;
  bool draw_track = false;
};

struct Binding {
    size_t         size  = 1;
    size_t         dsize = 1;
    nvinfer1::Dims dims;
    std::string    name;
};

// struct Object {
//     cv::Rect_<float> rect;
//     int              label = 0;
//     float            prob  = 0.0;
//     cv::Mat          boxMask;
// };

static constexpr int LOCATIONS = 4;

struct alignas(float) Object {
    //center_x center_y w h
    float bbox[LOCATIONS];
    float prob;  // bbox_conf * cls_conf
    float label;
    std::string name;
    cv::Rect rect;
    cv::Mat  boxMask;
};

struct PreParam {
    float ratio  = 1.0f;
    float dw     = 0.0f;
    float dh     = 0.0f;
    float height = 0;
    float width  = 0;
};



class YOLOv8_seg {
public:
    explicit YOLOv8_seg(const std::string& engine_file_path);
    ~YOLOv8_seg();
    // void                 inference(cv::Mat& share_mat, InsParams Iparams, std::vector<Object>& objs);
    void                 make_pipe(bool warmup = true, int verbose = 0);
    cv::Mat              copy_from_Mat(const cv::Mat& image);
    cv::Mat              copy_from_Mat(const cv::Mat& image, cv::Size& size);
    void                 letterbox(const cv::Mat& image, cv::Mat& out, cv::Size& size);
    void                 infer(cv::Mat& nchw, cv::Mat& protos, float* inferData, int seg_h, int seg_w);
    void                 infer();
    void                 postprocess(std::vector<Object>& objs,
                                     float                score_thres  = 0.25f,
                                     float                iou_thres    = 0.65f,
                                     int                  topk         = 100,
                                     int                  seg_channels = 32,
                                     int                  seg_h        = 160,
                                     int                  seg_w        = 160);
    void                 postprocess(float* output, 
                                     cv::Mat& protos,
                                     std::vector<Object>& objs,
                                     float                score_thres  = 0.25f,
                                     float                iou_thres    = 0.65f,
                                     int                  topk         = 100,
                                     int                  seg_channels = 32,
                                     int                  seg_h        = 160,
                                     int                  seg_w        = 160);
    cv::Mat              draw_objects(const cv::Mat&                                image,
                                      const std::vector<Object>&                    objs,
                                      const std::vector<std::string>&               CLASS_NAMES,
                                      const std::vector<std::vector<unsigned int>>& COLORS,
                                      const std::vector<std::vector<unsigned int>>& MASK_COLORS);
    int                  num_bindings;
    int                  num_inputs  = 0;
    int                  num_outputs = 0;
    std::vector<Binding> input_bindings;
    std::vector<Binding> output_bindings;
    std::vector<void*>   host_ptrs;
    std::vector<void*>   device_ptrs;

    float* host_output;

    PreParam pparam;


private:
    nvinfer1::ICudaEngine*       engine  = nullptr;
    nvinfer1::IRuntime*          runtime = nullptr;
    nvinfer1::IExecutionContext* context = nullptr;
    cudaStream_t                 stream  = nullptr;
    Logger                       gLogger{nvinfer1::ILogger::Severity::kERROR};


    std::vector<int>      labels;
    std::vector<float>    scores;
    std::vector<cv::Rect> bboxes;
    std::vector<cv::Mat>  mask_confs;
    std::vector<int>      indices;
    std::vector<cv::Mat> maskChannels;
    cv::Mat dest, mask_, mask, mask_conf, matmulRes, maskMat;
    cv::Rect roi;

    float cscore = 0.0f;
    float score = 0.0f;
    float x0 = 0.0f;
    float y0 = 0.0f;
    float x1 = 0.0f;
    float y1 = 0.0f;
    int label;

    int input_h, input_w, num_anchors, num_channels, scale_dw, scale_dh;
    float dw, dh, width, height, ratio;
};

#endif  // SEGMENT_SIMPLE_YOLOV8_SEG_HPP
