#include "yolov8-seg.hpp"

cv::Mat getline(std::vector<cv::Point>& points, cv::Mat& binaryMask)
{
    // 拟合曲线到这些坐标点
    cv::Mat curve;
    cv::fitLine(points, curve, cv::DIST_L2, 0, 0.01, 0.01);

    // 创建一个新的掩码
    cv::Mat newMask = cv::Mat::zeros(binaryMask.size(), CV_8UC1);

    // 将拟合曲线上的点渲染到新掩码上
    for (int i = 0; i < binaryMask.cols; ++i) {
        int y = (i - curve.at<float>(2)) * curve.at<float>(1) / curve.at<float>(0) + curve.at<float>(3);
        if (y >= 0 && y < binaryMask.rows) {
            newMask.at<uchar>(y, i) = 255;
        }
    }
    return newMask;
}

cv::Mat getpoly(std::vector<cv::Point>& points, cv::Mat& binaryMask, std::string& linenode, bool fixpoints)
{
    Eigen::VectorXd x(points.size() );
    Eigen::VectorXd y(points.size() );
    for (size_t i = 0; i < points.size() ; ++i) {
        x(i) = points[i].x;
        y(i) = points[i].y;
    }

    // Perform polynomial curve fitting (3rd degree polynomial in this example)
    Eigen::VectorXd coefficients = Eigen::VectorXd::Zero(4);
    Eigen::MatrixXd A(points.size() , 4);
    for (size_t i = 0; i < points.size() ; ++i) {
        A(i, 0) = 1.0;
        A(i, 1) = x(i);
        A(i, 2) = x(i) * x(i);
        A(i, 3) = x(i) * x(i) * x(i);
    }

    coefficients = (A.transpose() * A).ldlt().solve(A.transpose() * y);

#ifdef MASK_DEBUGER
    // cv::Mat newMask = binaryMask;
    cv::Mat newMask = cv::Mat::zeros(binaryMask.size(), CV_8UC1);
    // linenode = std::to_string(coefficients(3)) + " " + std::to_string(coefficients(2)) + " " + std::to_string(coefficients(1));
    linenode = std::to_string(newMask.cols) + " " + std::to_string(newMask.rows) + " " + std::to_string(newMask.rows * newMask.cols);
#else
    cv::Mat newMask = cv::Mat::zeros(binaryMask.size(), CV_8UC1);
#endif
    if(std::abs(coefficients(3)) > 0.0001) return newMask;
    if(std::abs(coefficients(2)) > 0.0015 && std::abs(coefficients(1)) > 1.5) return newMask;
    for (int i = 0; i < newMask.cols; ++i) {
        int y = coefficients(0) + coefficients(1) * i +
                coefficients(2) * i * i +
                coefficients(3) * i * i * i;
        if (fixpoints && i > newMask.cols * 0.7) break;
        if (y >= 0 && y < newMask.rows) newMask.at<uchar>(y, i) = 255;
    }
#ifdef MASK_DEBUGER
    // cv::putText(newMask, linenode, linepoint, cv::FONT_HERSHEY_PLAIN, 1.2, cv::Scalar(255), 2);
    // cv::imwrite("/media/ubuntu/G/projects/net-2d/instance-seg/deploy/yolov8/ud_vision_detection_v8/test/" + linenode + ".jpg", newMask);
#endif
    return newMask;
}


cv::Mat fixmask_fitpoly(cv::Mat& binaryMask)
{
    // Timer timer;
    // timer.tic();
    std::vector<cv::Point> points;
    for (int i = 0; i < binaryMask.rows; ++i) {
        for (int j = 0; j < binaryMask.cols; ++j) {
            if (binaryMask.at<uchar>(i, j) == 255) {
                points.push_back(cv::Point(j, i));
            }
        }
    }
    
    // Extract x and y coordinates
    Eigen::VectorXd x(points.size());
    Eigen::VectorXd y(points.size());
    for (size_t i = 0; i < points.size(); ++i) {
        x(i) = points[i].x;
        y(i) = points[i].y;
    }

    // Perform polynomial curve fitting (3rd degree polynomial in this example)
    Eigen::VectorXd coefficients = Eigen::VectorXd::Zero(4);
    Eigen::MatrixXd A(points.size(), 4);
    for (size_t i = 0; i < points.size(); ++i) {
        A(i, 0) = 1.0;
        A(i, 1) = x(i);
        A(i, 2) = x(i) * x(i);
        A(i, 3) = x(i) * x(i) * x(i);
    }

    coefficients = (A.transpose() * A).ldlt().solve(A.transpose() * y);

    // Create a new mask
    cv::Mat newMask = cv::Mat::zeros(binaryMask.size(), CV_8UC1);
    int st = -5;

    // Calculate points on the fitted curve and render them on the new mask
    for (int i = 0; i < binaryMask.cols; ++i) {
        int y = coefficients(0) + coefficients(1) * i +
                coefficients(2) * i * i +
                coefficients(3) * i * i * i;

        if (y >= 0 && y < binaryMask.rows) {
            newMask.at<uchar>(y, i) = 1;

            // for(int idx = 0; idx < 10; idx++)
            // {
            //     if(i+st+idx < 0) continue;
            //     if(i+st+idx > binaryMask.cols) continue;
            //     newMask.at<uchar>(y, i+st+idx) = 1;
            // }
        }
    }
    // timer.toc("fixmask");

    return newMask;

}

cv::Mat fixmask_fitpoly_combination(cv::Mat& binaryMask, std::string& linenode)
{
    Timer timer;
    std::vector<cv::Point> points;
    int break_thresh = 50;
    int break_num = 0;
    bool fixpoints = false;
    int points_size = 0;
    for (int j = 0; j < binaryMask.cols; ++j) {

        int count255 = cv::countNonZero(binaryMask.colRange(j, std::min(j + 1, binaryMask.cols))); // 统计列中值为255的点数量
        if (count255 == 0) break_num++;
        else break_num = 0;
        if (break_num > break_thresh) {
            fixpoints = true;
            
        }
        if(fixpoints && j > binaryMask.cols * 0.7) break;
        for (int i = 0; i < binaryMask.rows; ++i) {

            if (binaryMask.at<uchar>(i, j) == 255) {
                points.push_back(cv::Point(j, i));
            }
        }
    }
    // if (fixpoints) points_size = int(points.size() - points.size()/3);
    // else points_size = points.size();
    cv::Mat newMask;
    // if (fixpoints || binaryMask.rows * binaryMask.cols < 40000) newMask = getline(points, binaryMask);
    if (binaryMask.rows * binaryMask.cols < 20000) return cv::Mat::zeros(binaryMask.size(), CV_8UC1);
    // else newMask = getpoly(points, binaryMask);
#ifdef MASK_DEBUGER
    newMask = getpoly(points, binaryMask, linenode, fixpoints);
#else
    newMask = getpoly(points, binaryMask, linenode, fixpoints);
#endif
    return newMask;

}


YOLOv8_seg::YOLOv8_seg(const std::string& engine_file_path)
{
    std::ifstream file(engine_file_path, std::ios::binary);
    assert(file.good());
    file.seekg(0, std::ios::end);
    auto size = file.tellg();
    file.seekg(0, std::ios::beg);
    char* trtModelStream = new char[size];
    assert(trtModelStream);
    file.read(trtModelStream, size);
    file.close();
    initLibNvInferPlugins(&this->gLogger, "");
    this->runtime = nvinfer1::createInferRuntime(this->gLogger);
    assert(this->runtime != nullptr);

    this->engine = this->runtime->deserializeCudaEngine(trtModelStream, size);
    assert(this->engine != nullptr);
    delete[] trtModelStream;
    this->context = this->engine->createExecutionContext();

    assert(this->context != nullptr);
    cudaStreamCreate(&this->stream);
    this->num_bindings = this->engine->getNbBindings();

    for (int i = 0; i < this->num_bindings; ++i) {
        Binding            binding;
        nvinfer1::Dims     dims;
        nvinfer1::DataType dtype = this->engine->getBindingDataType(i);
        std::string        name  = this->engine->getBindingName(i);
        binding.name             = name;
        binding.dsize            = type_to_size(dtype);

        bool IsInput = engine->bindingIsInput(i);
        if (IsInput) {
            this->num_inputs += 1;
            dims         = this->engine->getProfileDimensions(i, 0, nvinfer1::OptProfileSelector::kMAX);
            binding.size = get_size_by_dims(dims);
            binding.dims = dims;
            this->input_bindings.push_back(binding);
            // set max opt shape
            this->context->setBindingDimensions(i, dims);
        }
        else {
            dims         = this->context->getBindingDimensions(i);
            binding.size = get_size_by_dims(dims);
            binding.dims = dims;
            this->output_bindings.push_back(binding);
            this->num_outputs += 1;
        }
    }
}

YOLOv8_seg::~YOLOv8_seg()
{
    this->context->destroy();
    this->engine->destroy();
    this->runtime->destroy();
    cudaStreamDestroy(this->stream);
    for (auto& ptr : this->device_ptrs) {
        CHECK(cudaFree(ptr));
    }

    for (auto& ptr : this->host_ptrs) {
        CHECK(cudaFreeHost(ptr));
    }
}

void YOLOv8_seg::make_pipe(bool warmup, int verbose)
{

    for (auto& bindings : this->input_bindings) {
        void* d_ptr;
        CHECK(cudaMallocAsync(&d_ptr, bindings.size * bindings.dsize, this->stream));
        this->device_ptrs.push_back(d_ptr);
    }

    for (auto& bindings : this->output_bindings) {
        void * d_ptr, *h_ptr;
        size_t size = bindings.size * bindings.dsize;
        CHECK(cudaMallocAsync(&d_ptr, size, this->stream));
        CHECK(cudaHostAlloc(&h_ptr, size, 0));
        this->device_ptrs.push_back(d_ptr);
        this->host_ptrs.push_back(h_ptr);
    }
    if (warmup) {
        std::vector<std::chrono::system_clock::time_point> stimes;
        for (int i = 0; i < 10; i++) {
            for (auto& bindings : this->input_bindings) {
                stimes.push_back(std::chrono::high_resolution_clock::now());
                size_t size  = bindings.size * bindings.dsize;
                void*  h_ptr = malloc(size);
                memset(h_ptr, 0, size);
                CHECK(cudaMemcpyAsync(this->device_ptrs[0], h_ptr, size, cudaMemcpyHostToDevice, this->stream));
                free(h_ptr);
                assert(stimes.begin() != stimes.end());

                std::chrono::system_clock::time_point endtime = std::chrono::high_resolution_clock::now();
                std::chrono::system_clock::time_point starttime = stimes.back();
                stimes.pop_back();
                std::chrono::duration<double> elapsed_seconds = endtime - starttime;
                if(verbose > 1) printf("%s cost %fms\n", "[warmup] inference only", elapsed_seconds.count()*1000);
            }
            this->infer();
        }
        // printf("model warmup 10 times\n");
    }
}

void YOLOv8_seg::letterbox(const cv::Mat& image, cv::Mat& out, cv::Size& size)
{

    const float inp_h  = size.height;
    const float inp_w  = size.width;
    float       height = image.rows;
    float       width  = image.cols;

    float r    = std::min(inp_h / height, inp_w / width);
    int   padw = std::round(width * r);
    int   padh = std::round(height * r);

    cv::Mat tmp;
    if ((int)width != padw || (int)height != padh) {
        cv::resize(image, tmp, cv::Size(padw, padh));
    }
    else {
        tmp = image.clone();
    }

    float dw = inp_w - padw;
    float dh = inp_h - padh;

    dw /= 2.0f;
    dh /= 2.0f;
    int top    = int(std::round(dh - 0.1f));
    int bottom = int(std::round(dh + 0.1f));
    int left   = int(std::round(dw - 0.1f));
    int right  = int(std::round(dw + 0.1f));

    cv::copyMakeBorder(tmp, tmp, top, bottom, left, right, cv::BORDER_CONSTANT, {114, 114, 114});
    cv::dnn::blobFromImage(tmp, out, 1 / 255.f, cv::Size(), cv::Scalar(0, 0, 0), true, false, CV_32F);

    this->pparam.ratio  = 1 / r;
    this->pparam.dw     = dw;
    this->pparam.dh     = dh;
    this->pparam.height = height;
    this->pparam.width  = width;
    ;
}

cv::Mat YOLOv8_seg::copy_from_Mat(const cv::Mat& image)
{
    cv::Mat  nchw;
    auto&    in_binding = this->input_bindings[0];
    auto     width      = in_binding.dims.d[3];
    auto     height     = in_binding.dims.d[2];
    cv::Size size{width, height};
    this->letterbox(image, nchw, size);

    this->context->setBindingDimensions(0, nvinfer1::Dims{4, {1, 3, height, width}});
    return nchw;
    
}

cv::Mat YOLOv8_seg::copy_from_Mat(const cv::Mat& image, cv::Size& size)
{
    cv::Mat nchw;
    this->letterbox(image, nchw, size);

    this->context->setBindingDimensions(0, nvinfer1::Dims{4, {1, 3, size.height, size.width}});
    return nchw;

    
}

void YOLOv8_seg::infer()
{
    this->context->enqueueV2(this->device_ptrs.data(), this->stream, nullptr);
    for (int i = 0; i < this->num_outputs; i++) {
        size_t osize = this->output_bindings[i].size * this->output_bindings[i].dsize;
        CHECK(cudaMemcpyAsync(
            this->host_ptrs[i], this->device_ptrs[i + this->num_inputs], osize, cudaMemcpyDeviceToHost, this->stream));
    }
    cudaStreamSynchronize(this->stream);
}

void YOLOv8_seg::infer(cv::Mat& nchw, cv::Mat& protos, float* tmp, int seg_h, int seg_w)
{
    CHECK(cudaMemcpyAsync(
        this->device_ptrs[0], nchw.ptr<float>(), nchw.total() * nchw.elemSize(), cudaMemcpyHostToDevice, this->stream));
    
    this->context->enqueueV2(this->device_ptrs.data(), this->stream, nullptr);
    for (int i = 0; i < this->num_outputs; i++) {
        size_t osize = this->output_bindings[i].size * this->output_bindings[i].dsize;
        CHECK(cudaMemcpyAsync(
            this->host_ptrs[i], this->device_ptrs[i + this->num_inputs], osize, cudaMemcpyDeviceToHost, this->stream));
    }
    cudaStreamSynchronize(this->stream);
    size_t size = output_bindings[0].size * output_bindings[0].dsize;
    float* output = static_cast<float*>(this->host_ptrs[0]);
    std::memcpy(tmp, output, size);
    protos = cv::Mat(32, seg_h * seg_w, CV_32F, static_cast<float*>(this->host_ptrs[1])).clone();
}

void YOLOv8_seg::postprocess(float* output, cv::Mat& protos,
    std::vector<Object>& objs, float score_thres, float iou_thres, int topk, int seg_channels, int seg_h, int seg_w)
{
    // Timer timera;
    // Timer timer;
    // timera.tic();
    
    objs.clear();
    labels.clear();
    scores.clear();
    bboxes.clear();
    mask_confs.clear();
    indices.clear();

    input_h      = this->input_bindings[0].dims.d[2];
    input_w      = this->input_bindings[0].dims.d[3];
    num_anchors  = this->output_bindings[0].dims.d[1];
    num_channels = this->output_bindings[0].dims.d[2];

    dw     = this->pparam.dw;
    dh     = this->pparam.dh;
    width  = this->pparam.width;
    height = this->pparam.height;
    ratio  = this->pparam.ratio;


    scale_dw = dw / input_w * seg_w;
    scale_dh = dh / input_h * seg_h;
    roi = cv::Rect(scale_dw, scale_dh, seg_w - 2 * scale_dw, seg_h - 2 * scale_dh);


    // timer.tic();
    for (int i = 0; i < num_anchors; i++) {
        float* ptr   = output + i * num_channels;
        score = *(ptr + 4);
        if (*(ptr + 5) == 5) cscore = 0.3f;
        else cscore = score_thres;
        if (score > cscore) {
            x0 = *ptr++ - dw;
            y0 = *ptr++ - dh;
            x1 = *ptr++ - dw;
            y1 = *ptr++ - dh;

            x0 = clamp(x0 * ratio, 0.f, width);
            y0 = clamp(y0 * ratio, 0.f, height);
            x1 = clamp(x1 * ratio, 0.f, width);
            y1 = clamp(y1 * ratio, 0.f, height);

            label = *(++ptr);
            mask_conf = cv::Mat(1, seg_channels, CV_32F, ++ptr);
            mask_confs.push_back(mask_conf);
            labels.push_back(label);
            scores.push_back(score);
            bboxes.push_back(cv::Rect_<float>(x0, y0, x1 - x0, y1 - y0));
        }
    }
    // timer.toc("[get res from device]");
    // timer.tic();

#if defined(BATCHED_NMS)
    cv::dnn::NMSBoxesBatched(bboxes, scores, labels, score_thres, iou_thres, indices);
#else
    cv::dnn::NMSBoxes(bboxes, scores, score_thres, iou_thres, indices);
#endif

    // timer.toc("[nms]");
    // timer.tic();

    cv::Mat masks;
    int     cnt = 0;
    for (auto& i : indices) {
        if (cnt >= topk) {
            break;
        }
        cv::Rect tmp = bboxes[i];
        Object   obj;
        obj.label = labels[i];
        obj.rect  = tmp;
        obj.prob  = scores[i];
        obj.bbox[0] = bboxes[i].x + width/2;
        obj.bbox[1] = bboxes[i].y + height/2;
        obj.bbox[2] = bboxes[i].width;
        obj.bbox[3] = bboxes[i].height;
        masks.push_back(mask_confs[i]);
        objs.push_back(obj);
        cnt += 1;
    }
    std::string _;

    if (masks.empty()) {
        // masks is empty
    }
    else {
        matmulRes = (masks * protos).t();
        maskMat   = matmulRes.reshape(indices.size(), {seg_w, seg_h});
        cv::split(maskMat, maskChannels);
        for (int i = 0; i < indices.size(); i++) {
            // here to limit the number of mask
            // if (objs[i].label != 5) continue;
            cv::exp(-maskChannels[i](roi), dest);

            dest = 1.0 / (1.0 + dest);

            // 1920 1080
            // cv::resize(dest, mask, cv::Size(640, 640), cv::INTER_CUBIC);
            cv::resize(dest, mask, cv::Size((int)width, (int)height), cv::INTER_NEAREST);

            objs[i].boxMask = mask(objs[i].rect) > 0.5f;
           
            // if(objs[i].label == 5) {
            // #ifdef MASK_DEBUGER
            //     objs[i].boxMask = fixmask_fitpoly_combination(objs[i].boxMask, objs[i].name);
            // #else
            //     objs[i].boxMask = fixmask_fitpoly_combination(objs[i].boxMask, _);
            // #endif
            // }
        }

    }
    // timera.toc("post all");

}


void YOLOv8_seg::postprocess(
    std::vector<Object>& objs, float score_thres, float iou_thres, int topk, int seg_channels, int seg_h, int seg_w)
{

    objs.clear();
    auto input_h      = this->input_bindings[0].dims.d[2];
    auto input_w      = this->input_bindings[0].dims.d[3];
    auto num_anchors  = this->output_bindings[0].dims.d[1];
    auto num_channels = this->output_bindings[0].dims.d[2];

    auto& dw     = this->pparam.dw;
    auto& dh     = this->pparam.dh;
    auto& width  = this->pparam.width;
    auto& height = this->pparam.height;
    auto& ratio  = this->pparam.ratio;

    auto*   output = static_cast<float*>(this->host_ptrs[0]);
    cv::Mat protos = cv::Mat(seg_channels, seg_h * seg_w, CV_32F, static_cast<float*>(this->host_ptrs[1]));

    std::vector<int>      labels;
    std::vector<float>    scores;
    std::vector<cv::Rect> bboxes;
    std::vector<cv::Mat>  mask_confs;
    std::vector<int>      indices;

    for (int i = 0; i < num_anchors; i++) {
        float* ptr   = output + i * num_channels;
        float  score = *(ptr + 4);
        if (score > score_thres) {
            float x0 = *ptr++ - dw;
            float y0 = *ptr++ - dh;
            float x1 = *ptr++ - dw;
            float y1 = *ptr++ - dh;

            x0 = clamp(x0 * ratio, 0.f, width);
            y0 = clamp(y0 * ratio, 0.f, height);
            x1 = clamp(x1 * ratio, 0.f, width);
            y1 = clamp(y1 * ratio, 0.f, height);

            int     label     = *(++ptr);
            cv::Mat mask_conf = cv::Mat(1, seg_channels, CV_32F, ++ptr);
            mask_confs.push_back(mask_conf);
            labels.push_back(label);
            scores.push_back(score);
            bboxes.push_back(cv::Rect_<float>(x0, y0, x1 - x0, y1 - y0));
        }
    }

#if defined(BATCHED_NMS)
    cv::dnn::NMSBoxesBatched(bboxes, scores, labels, score_thres, iou_thres, indices);
#else
    cv::dnn::NMSBoxes(bboxes, scores, score_thres, iou_thres, indices);
#endif

    cv::Mat masks;
    int     cnt = 0;
    for (auto& i : indices) {
        if (cnt >= topk) {
            break;
        }
        cv::Rect tmp = bboxes[i];
        Object   obj;
        obj.label = labels[i];
        obj.rect  = tmp;
        obj.prob  = scores[i];
        obj.bbox[0] = bboxes[i].x + width/2;
        obj.bbox[1] = bboxes[i].y + height/2;
        obj.bbox[2] = bboxes[i].width;
        obj.bbox[3] = bboxes[i].height;
        masks.push_back(mask_confs[i]);
        objs.push_back(obj);
        cnt += 1;
    }

    if (masks.empty()) {
        // masks is empty
    }
    else {
        cv::Mat matmulRes = (masks * protos).t();
        cv::Mat maskMat   = matmulRes.reshape(indices.size(), {seg_w, seg_h});

        std::vector<cv::Mat> maskChannels;
        cv::split(maskMat, maskChannels);
        int scale_dw = dw / input_w * seg_w;
        int scale_dh = dh / input_h * seg_h;

        cv::Rect roi(scale_dw, scale_dh, seg_w - 2 * scale_dw, seg_h - 2 * scale_dh);

        for (int i = 0; i < indices.size(); i++) {
            // here to limit the number of mask
            // if (objs[i].label != 2) continue;
            cv::Mat dest, mask;
            cv::exp(-maskChannels[i], dest);
            dest = 1.0 / (1.0 + dest);
            dest = dest(roi);
            cv::resize(dest, mask, cv::Size((int)width, (int)height), cv::INTER_LINEAR);
            objs[i].boxMask = mask(objs[i].rect) > 0.5f;

        }
    }
}

cv::Mat YOLOv8_seg::draw_objects(const cv::Mat&                                image,
                              const std::vector<Object>&                    objs,
                              const std::vector<std::string>&               CLASS_NAMES,
                              const std::vector<std::vector<unsigned int>>& COLORS,
                              const std::vector<std::vector<unsigned int>>& MASK_COLORS)
{
    cv::Mat res = image;
    cv::Mat mask = image.clone();
    for (auto& obj : objs) {
        int        idx   = obj.label;

#ifdef MASK_DEBUGER
        if(idx != 5) continue;
#endif
        
        cv::Scalar color = cv::Scalar(COLORS[idx][0], COLORS[idx][1], COLORS[idx][2]);
        cv::Scalar mask_color =
            cv::Scalar(MASK_COLORS[idx % 20][0], MASK_COLORS[idx % 20][1], MASK_COLORS[idx % 20][2]);
        cv::rectangle(res, obj.rect, color, 2);

        char text[256];
        sprintf(text, "%s %.1f%%", CLASS_NAMES[idx].c_str(), obj.prob * 100);
        mask(obj.rect).setTo(mask_color, obj.boxMask);

        int      baseLine   = 0;
        cv::Size label_size = cv::getTextSize(text, cv::FONT_HERSHEY_SIMPLEX, 0.4, 1, &baseLine);

        int x = (int)obj.rect.x;
        int y = (int)obj.rect.y + 1;

        if (y > res.rows)
            y = res.rows;

        cv::rectangle(res, cv::Rect(x, y, label_size.width, label_size.height + baseLine), {0, 0, 255}, -1);

#ifdef MASK_DEBUGER
        cv::putText(mask, obj.name, cv::Point(x, y + label_size.height), cv::FONT_HERSHEY_SIMPLEX, 0.5, {255, 255, 255}, 1);
#else
        cv::putText(res, text, cv::Point(x, y + label_size.height), cv::FONT_HERSHEY_SIMPLEX, 1, {255, 255, 255}, 2);
#endif
    }
    cv::addWeighted(res, 0.5, mask, 0.8, 1, res);
    return mask;
}

// void YOLOv8_seg::inference(cv::Mat& share_mat, InsParams Iparams, std::vector<Object>& objs)
// {
//     copy_from_Mat(share_mat, Iparams.size);
//     infer();
//     postprocess(objs, Iparams.score_thres, Iparams.iou_thres, Iparams.topk, Iparams.seg_channels, Iparams.seg_h, Iparams.seg_w);
// }
