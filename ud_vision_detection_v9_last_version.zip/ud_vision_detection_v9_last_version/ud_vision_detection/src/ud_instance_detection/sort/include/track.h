#ifndef _TRACK_H
#define _TRACK_H

#pragma once

#include <opencv2/core.hpp>
#include "kalman_filter.h"
#include "yololayer.h"
#include "yolov8-seg.hpp"

class Track {
public:
    // Constructor
    Track();

    // Destructor
    ~Track() = default;

    // void Init(const cv::Rect &bbox);
    void Init(const Object &detection);

    void Predict();

    // void Update(const cv::Rect &bbox);
    void Update(const Object &detection);

    cv::Rect GetStateAsBbox() const;

    float GetNIS() const;

    int coast_cycles_ = 0, hit_streak_ = 0;

    float detect_class_ = 0, detect_conf_ = 0.0;

    cv::Mat mask_;

private:
    Eigen::VectorXd ConvertBboxToObservation(const cv::Rect &bbox) const;

    cv::Rect ConvertStateToBbox(const Eigen::VectorXd &state) const;

    KalmanFilter kf_;
};

#endif  // _TRACK_H