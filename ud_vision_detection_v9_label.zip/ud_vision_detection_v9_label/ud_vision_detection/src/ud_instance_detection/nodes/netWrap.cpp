#include "netWrap.hpp"


// ------------- InstanceROS -------------
InstanceROS::InstanceROS()
{
    std::string node_name_ = ros::this_node::getName();
    nh.param<std::string>(ros::this_node::getName()+"/modelpath",       modelpath,   "/media/ubuntu/G/projects/net-2d/instance-seg/deploy/yolov8");
    nh.param<std::string>(ros::this_node::getName()+"/modeltype",       modeltype,   "FP16"); // not use yet for version3
    nh.param<std::string>(ros::this_node::getName()+"/subtopic1",       subtopic1,   "/ud_camera5");
    nh.param<std::string>(ros::this_node::getName()+"/subtopic2",       subtopic2,   "/ud_camera6");
    nh.param<std::string>(ros::this_node::getName()+"/subtopic3",       subtopic3,   "/ud_camera7");
    nh.param<std::string>(ros::this_node::getName()+"/subtopic4",       subtopic4,   "/ud_camera8");
    nh.param<std::string>(ros::this_node::getName()+"/frameid",         frameid,     "frameid");
    nh.param<std::string>(ros::this_node::getName()+"/calib_root",      calib_root,  "/media/ubuntu/G/projects/net-3d/pointcloud-deploy/depoly_v2/int8_data");
    nh.param<std::string>(ros::this_node::getName()+"/calib_file",      calib_file,  "/media/ubuntu/G/projects/net-3d/pointcloud-deploy/depoly_v2/int8_txt.txt");
    nh.param<std::string>(ros::this_node::getName()+"/json_root",       json_root,   "/media/ubuntu/G/projects/Steven_projects/2DNet/instance-seg/deploy/yolov8-deploy/ud_vision_detection_v9_label/ud_vision_detection/test");
    nh.param<int>(ros::this_node::getName()+"/verbose",                 verbose,     1);
    nh.param<int>(ros::this_node::getName()+"/img_size",                img_size,    960);
    nh.param<bool>(ros::this_node::getName()+"/userosbag",              userosbag,   false);
    nh.param<bool>(ros::this_node::getName()+"/usezmq",                 usezmq,      true);

    for (int i = 0; i < CHN; ++i) { 
        std::string dire = DIRECTION[i];
        std::string infer_topic = "ud_instance_image_" + dire;
        std::string object_topic = "ud_" + dire + "_instance_detect";
        infer_pubers[i] = nh.advertise<sensor_msgs::Image>(infer_topic, 10);
        object_pubers[i] = nh.advertise<autoware_msgs::DetectedObjectArray>(object_topic, 10);
    }
#ifdef RIGHTMODELCOMPARE
    int rightcompareid;
    nh.param<int>(ros::this_node::getName()+"/rightcompareid",                rightcompareid,     1);
    subtopic1 = "/ud_camera8";
    std::string temp = "/compare" + std::to_string(rightcompareid);
    infer_pubers[0] = nh.advertise<sensor_msgs::Image>(temp, 10);
#endif
    seg_size = img_size==960? 240:img_size==1280? 320 : 160;
    Iparams         = set_seg_param();
#ifdef USE_COMPRESSED_IMAGE
    subtopic1 += "/compressed";
    subtopic2 += "/compressed";
    subtopic3 += "/compressed";
    subtopic4 += "/compressed";
#endif
    subtopics.push_back(subtopic1);
    subtopics.push_back(subtopic3);
    subtopics.push_back(subtopic4);
    subtopics.push_back(subtopic2);
}


// ------------- InstanceModel -------------
InstanceModel::InstanceModel(){}

InstanceModel::~InstanceModel(){}

void InstanceModel::init()
{
    for (int i = 0; i < CHN; ++i) Inets[i]  = std::unique_ptr<YOLOv8_seg>(new YOLOv8_seg(modelpath));
}

void InstanceModel::logout()
{
  if(verbose!=0)
  {
    printf("------------------ Model init finished -----------------------\n");
    std::cout<<"[InstanceROS] modelpath  : "<<modelpath<<std::endl;
    // std::cout<<"[InstanceROS] modeltype  : "<<modeltype<<std::endl;
    std::cout<<"[InstanceROS] verbose    : "<<verbose<<std::endl;
    std::cout<<"[InstanceROS] frameid    : "<<frameid<<std::endl;
    std::cout<<"[InstanceROS] img_size   : "<<img_size<<std::endl;
    std::cout<<"[InstanceROS] seg_size   : "<<seg_size<<std::endl;
    std::cout<<"[InstanceROS] subtopic1  : "<<subtopic1<<std::endl;
    std::cout<<"[InstanceROS] subtopic2  : "<<subtopic2<<std::endl;
    std::cout<<"[InstanceROS] subtopic3  : "<<subtopic3<<std::endl;
    std::cout<<"[InstanceROS] subtopic4  : "<<subtopic4<<std::endl;
    for (int i = 0; i < CHN; ++i) {
        std::string dire = DIRECTION[i];
        std::string infer_topic = "ud_instance_image_" + dire;
        std::string object_topic = "ud_" + dire + "_instance_detect";
        std::cout<<"[InstanceROS] inftopic"<<i<<"  : "<<infer_topic<<std::endl;
        std::cout<<"[InstanceROS] objtopic"<<i<<"  : "<<object_topic<<std::endl;

    }
    if(modeltype == "INT8"){
      std::cout<<"[InstanceROS] calib_root : "<<calib_root<<std::endl;
      std::cout<<"[InstanceROS] calib_file : "<<calib_file<<std::endl;
    }
    printf("------------------ Model init finished -----------------------\n");
  }
  

}

void InstanceModel::warmup()
{    
    for (int i = 0; i < CHN; ++i) {
        Inets[i]->make_pipe(true, verbose);
    }
}

void InstanceModel::infer_from_source()
{
    for(int i = 0; i < CHN; ++i){
        if(usezmq) zmq_threads[i] = std::thread(&InstanceModel::callback_from_zmq, this, i);
         
#ifdef USE_COMPRESSED_IMAGE
        else img_subs[i] = get_nh().subscribe<sensor_msgs::CompressedImage>(subtopics[i], 10, boost::bind(&InstanceModel::callback_from_topic, this, _1, i));
#else
        else img_subs[i] = get_nh().subscribe<sensor_msgs::Image>(subtopics[i], 10, boost::bind(&InstanceModel::callback_from_topic, this, _1, i));
#endif
    }
    // ros::Subscriber img_sub4 = get_nh().subscribe<sensor_msgs::CompressedImage>(subtopic4, 10, boost::bind(&InstanceModel::callback_from_topic, this, _1, 3));
    for(int i = 0; i < CHN; ++i) {
        usleep(100000); //100ms
        infer_threads[i] = std::thread(&InstanceModel::infer_type_RGBIMG, this, i);
    }

    ros::spin();
}

#ifdef USE_COMPRESSED_IMAGE
void InstanceModel::callback_from_topic(const sensor_msgs::CompressedImageConstPtr& msg, int chn)
{
    InsData data;
    msg_in[chn] = msg;
    g_curt_timer[chn] = msg_in[chn]->header.stamp.toSec();
    data.header = msg_in[chn]->header;
    data.share_mat = msg2cvmat(msg_in[chn]).clone();
    data_queues[chn].push(data);
    #ifdef INPUT_CALLBACK_DEBUGER
    std::cout << "Callback from topic "<< chn << " mat_queue.size() = " <<data_queues[chn].size()<< std::endl;
    #endif
}
#else
void InstanceModel::callback_from_topic(const sensor_msgs::ImageConstPtr& msg, int chn)
{
    InsData data;
    msg_in[chn] = msg;
    g_curt_timer[chn] = msg_in[chn]->header.stamp.toSec();
    data.header = msg_in[chn]->header;
    data.share_mat = msg2cvmat(msg_in[chn]).clone();
    data_queues[chn].push(data);
    #ifdef INPUT_CALLBACK_DEBUGER
    std::cout << "Callback from topic "<< chn << " mat_queue.size() = " <<data_queues[chn].size()<< std::endl;
    #endif
}
#endif

void InstanceModel::callback_from_zmq(int chn)
{
    std::map<int, std::string> camera_chn = {{0,"ud_camera5"}, {1,"ud_camera7"}, {2,"ud_camera8"}, {3,"ud_camera6"}};
    std::string channel_file = camera_chn[chn];
    zmq::context_t context_ = zmq::context_t(1);
    zmq::socket_t *socket_ = new::zmq::socket_t(context_, ZMQ_SUB);
    std::string endpoint = "ipc:///tmp/" + std::string(channel_file);
    socket_->connect(endpoint);
    socket_->setsockopt(ZMQ_SUBSCRIBE, nullptr, 0);
    std::cout<<"Callback zmq subcribe from : "<<channel_file<<std::endl;  
    while(true)
    {
        zmq::message_t raw_msg;
        auto ok = socket_->recv(&raw_msg);
        if(ok)
        {            
            #ifdef INPUT_CALLBACK_DEBUGER
            std::cout << "Callback from topic "<< chn << " mat_queue.size() = " <<data_queues[chn].size()<< std::endl;
            #endif
            std::string msg = std::string(static_cast<char *>(raw_msg.data()), raw_msg.size());
            
            if (msg == "zzz" ||  msg.size() <=0)
            continue;

            sensor_msgs::udImage udcomperssImage;   

            if(udcomperssImage.ParseFromString(msg))
            {
                Msgcalback(udcomperssImage, chn);
            }
            else
            {
                std::cout<<"[ZMQ] error parse msg :(, This should't happend. "<<std::endl;
                usleep(200000); //1s
            }   
        }
    }
}

void InstanceModel::Msgcalback(const sensor_msgs::udImage &q_image, int chn)
{
    bool useimdecode = false;
    std::chrono::system_clock::time_point _start = std::chrono::system_clock::now();

    cv::Mat img_decode, img;
    std::vector<uchar> data_encode;
        
    size_t dataSize = q_image.width() * q_image.height() * q_image.elt_size();

    if(!useimdecode)
    {
    img_decode.create(q_image.height(), q_image.width(), CV_8UC3);   
    }

    data_encode.resize(dataSize);

    std::chrono::system_clock::time_point _start1 = std::chrono::system_clock::now();   

    if(useimdecode)//run time: 20ms
    {    
    auto img_data = q_image.mat_data(); 
    std::copy(img_data.begin(), img_data.end(), data_encode.data());
    img_decode = cv::imdecode(data_encode, cv::IMREAD_COLOR);
    }
    else// run time: 0~1ms
    { 
        img_decode.data = std::move(reinterpret_cast<uchar*>(const_cast<char*>(q_image.mat_data().c_str())));
    }

    InsData data;
    data.share_mat = img_decode.clone();
    data.header.stamp.sec = q_image.sec();
    data.header.stamp.nsec = q_image.nsec();
    data.header.frame_id = "ud_camera";
    data_queues[chn].push(data);

    std::chrono::system_clock::time_point _end1 = std::chrono::system_clock::now();
    //   std::cout <<"sub use imdecode true or false:"<< useimdecode <<" run time:" <<std::chrono::duration_cast<std::chrono::milliseconds>(_end1 - _start1).count() << "ms" << std::endl;

    //   std::cout <<"sub all run time:" <<std::chrono::duration_cast<std::chrono::milliseconds>(_end1  - _start).count() << "ms" << std::endl;

    //img_decode.data maybe not continus  
    if(img_decode.empty())
    return;
    
}

/*
void Speed_Tracker::trk2DetectedObject(InsParams Iparams, const std::pair<const int, Track> trk, autoware_msgs::DetectedObject &detect_obj)
{
    const auto &bbox = trk.second.GetStateAsBbox();
    const auto &mask = trk.second.mask_;
    detect_obj.x = static_cast<float>(bbox.tl().x); 
    detect_obj.y = static_cast<float>(bbox.tl().y);
    detect_obj.width = static_cast<float>(bbox.width);
    detect_obj.height = static_cast<float>(bbox.height);
    detect_obj.label = static_cast<std::string>(Iparams.class_labels[(int)trk.second.detect_class_]);
    detect_obj.score = static_cast<float>(trk.second.detect_conf_);
    detect_obj.id = trk.first;
    detect_obj.color = std_msgs::ColorRGBA();
    detect_obj.color.a = 0;
    detect_obj.color.r = Iparams.detect_colors[trk.first % 100][0];
    detect_obj.color.b = Iparams.detect_colors[trk.first % 100][1];
    detect_obj.color.g = Iparams.detect_colors[trk.first % 100][2];
    detect_obj.indicator_state = 0.0;  // using indecator_state to count tracked times
    detect_obj.roi_image = cvmat2msg_(mask);
}

void Speed_Tracker::run(InsParams Iparams, std::vector<Object>& objs, cv::Mat& share_mat)
{
    sort.Run(objs);
    tracks = sort.GetTracks();
    for (auto &trk: tracks) {
        const auto &bbox = trk.second.GetStateAsBbox();
        // if () 
        if (trk.second.coast_cycles_ < kMaxCoastCycles && (trk.second.hit_streak_ >= kMinHits || 1 < kMinHits)) 
        {
            autoware_msgs::DetectedObject detect_obj;
            trk2DetectedObject(Iparams, trk, detect_obj);
            detect_objs.objects.push_back(detect_obj);  
            char t[256];
            sprintf(t, "%.2f", detect_obj.score);
            std::string display_name = detect_obj.label + " - ID: " + std::to_string(trk.first);
            if(Iparams.draw_track){
                cv::rectangle(share_mat, cv::Rect(bbox.tl().x, bbox.tl().y, bbox.width, bbox.height), Iparams.class_colors[(int)trk.second.detect_class_], 2);
                cv::putText(share_mat, display_name, cv::Point(bbox.tl().x, bbox.tl().y - 1), cv::FONT_HERSHEY_PLAIN, 1.2, Iparams.class_colors[(int)trk.second.detect_class_], 2);
            }   
        }
    }
}
*/

void InstanceModel::infer_type_RGBIMG(int chn)
{
    printf("[Thread%d start]\n", chn);
    Tracker sort;
    Timer timer;
    int count = 0;
    int idx = 0;
    std::string timerlog = "[CHN" + std::to_string(chn) + "]"; 
    cv::Mat share_mat;
    cv::Mat protos;
    ros::Time share_stamp;
    float* inferData = new float[1276800];
    InsData data;
    cv::Mat preprocessImg;
    tic_counter();

    while(g_running){
        // usleep(50000); //50ms

        if(data_queues[chn].size() == 0) {usleep(5000);continue;}

        // 1. clear containers
        autoware_msgs::DetectedObjectArray detect_objs;
        std::vector<Object> objs;

        // 2. get input
        // while(!check_status(chn, PREPROCESS, share_stamp.toSec())) {usleep(SLEEPTIME);}
        while(!check_status(chn, PREPROCESS)) usleep(SLEEPTIME);
        timer.tic();
        timer.tic_fps();

        while (data_queues[chn].size() > 1) data_queues[chn].pop();
        data = *(data_queues[chn].pop());
        share_mat = data.share_mat;
        // cv::resize(share_mat, share_mat, Iparams.size, cv::INTER_NEAREST);
        share_stamp = data.header.stamp;
        preprocessImg = Inets[chn]->copy_from_Mat(share_mat, Iparams.size);
        
        while(!check_status(chn, INFER)) usleep(SLEEPTIME); 
        Inets[chn]->infer(preprocessImg, protos, inferData, Iparams.seg_h, Iparams.seg_w);

        while(!check_status(chn, POSTPROCESS)) usleep(SLEEPTIME); 
        Inets[chn]->postprocess(inferData, protos, objs, Iparams.score_thres, Iparams.iou_thres, Iparams.topk, Iparams.seg_channels, Iparams.seg_h, Iparams.seg_w);
        
        while(!check_status(chn, TRACK)) usleep(SLEEPTIME); 
        track(chn, data, Iparams, objs, detect_objs, sort);
        object_pubers[chn].publish(detect_objs); // publish information of processed (classes, prob, x, y, w, h, boxmask)

        #ifdef USE_SAVEJSON
        saveJson(detect_objs, share_mat, json_root, chn);
        #endif

        if(userosbag)
        {
            while(!check_status(chn, DRAW)) usleep(SLEEPTIME); 
            cv::Mat draw_mat =  Iparams.draw_track ? share_mat : Inets[chn]->draw_objects(share_mat, objs, CLASS_NAMES, COLORS, MASK_COLORS);
            // draw_mat = Inets[chn]->draw_objects(share_mat, objs, CLASS_NAMES, COLORS, MASK_COLORS);
            // cv::imwrite("/media/ubuntu/G/projects/net-2d/instance-seg/deploy/yolov8/ud_vision_detection_v8/test/"+std::to_string(chn)+"/"+std::to_string(idx)+".jpg", draw_mat);
            // cv::resize(draw_mat, draw_mat, cv::Size(1920, 1080), cv::INTER_NEAREST);
        
            idx++;
            infer_pubers[chn].publish(*cvmat2msg(draw_mat));
        }

        check_status(chn, FINISHED);
        if(verbose == 1) timer.toc_fps(count, chn);
        if(verbose == 2) timer.toc(timerlog);
        toc_counter();
    }

}


void InstanceModel::track(int chn, InsData& data, InsParams Iparams, std::vector<Object>& objs, autoware_msgs::DetectedObjectArray& detect_objs,  Tracker sort)
{
    cv::Mat share_mat = data.share_mat;
    std_msgs::Header input_header = data.header;
    input_header.frame_id = data.header.frame_id;
    std::vector<cv::Scalar> detect_colors;
    std::map<int, std::string> class_labels{
        {0, "curb"},
        {1, "person"},
        {2, "car"},
        {3, "bicycle"},
        {4, "free_object"},
        {5, "lane_marking"},
        {6, "traffic_sign"},
        {7, "truck"},
        {8, "zebra_crossing"},
        {9, "waiting_object"},
        {10, "obstacle"},
    };
    std::vector<cv::Scalar> class_colors;
    class_colors.resize(class_labels.size());
    srand((int) time(nullptr));
    for (cv::Scalar &class_color: class_colors)
        class_color = cv::Scalar(rand() % 255, rand() % 255, rand() % 255);

    detect_objs.header.stamp = input_header.stamp;
    detect_objs.header.frame_id = input_header.frame_id;
    // tracker SORT -------------------------------------
    auto sort_start = std::chrono::system_clock::now();

    sort.Run(objs);
    std::map<int, Track> tracks = sort.GetTracks();

    detect_colors.resize(100);
    srand((int) time(nullptr));
    for (cv::Scalar &detect_color: detect_colors)
        detect_color = cv::Scalar(rand() % 255, rand() % 255, rand() % 255,  0);
    for (auto &trk: tracks) {
        const auto &bbox = trk.second.GetStateAsBbox();
        const auto &mask = trk.second.mask_;

        if (trk.second.coast_cycles_ < kMaxCoastCycles && (trk.second.hit_streak_ >= kMinHits || 1 < kMinHits)) 
        {

            autoware_msgs::DetectedObject detect_obj;
            detect_obj.x = static_cast<float>(bbox.tl().x); 
            detect_obj.y = static_cast<float>(bbox.tl().y);
            detect_obj.width = static_cast<float>(bbox.width);
            detect_obj.height = static_cast<float>(bbox.height);
            detect_obj.label = static_cast<std::string>(class_labels[(int)trk.second.detect_class_]);
            detect_obj.score = static_cast<float>(trk.second.detect_conf_);
            detect_obj.id = trk.first;
            detect_obj.color = std_msgs::ColorRGBA();
            detect_obj.color.a = 0;
            detect_obj.color.r = detect_colors[trk.first % 100][0];
            detect_obj.color.b = detect_colors[trk.first % 100][1];
            detect_obj.color.g = detect_colors[trk.first % 100][2];
            detect_obj.indicator_state = 0.0;  // using indecator_state to count tracked times
            // detect_obj.mask_width = mask.cols;  
            // detect_obj.mask_height = mask.rows;  
            
            // mask roiimage 
            // detect_obj.roi_image = cvmat2msg_(mask);

            // mask bool[]
            // std::vector<bool> boolvec = cvmat2bools(mask); 
            // for (auto mb : boolvec) detect_obj.bool_mask.push_back(mb);

            // mask int[] (255 start2end index vector)
            std::vector<int> intvec = cvmat2ints(mask); 
            for (auto mi : intvec) detect_obj.int_mask.push_back(mi);

            
            detect_objs.objects.push_back(detect_obj);  
            char t[256];
            sprintf(t, "%.2f", detect_obj.score);

            // get class name
            std::string display_name = detect_obj.label + " - ID: " + std::to_string(trk.first);
            if (Iparams.draw_track)
            {
                cv::rectangle(share_mat, cv::Rect(bbox.tl().x, bbox.tl().y, bbox.width, bbox.height), class_colors[(int)trk.second.detect_class_], 2);
                cv::putText(share_mat, display_name, cv::Point(bbox.tl().x, bbox.tl().y - 1), cv::FONT_HERSHEY_PLAIN, 1.2, class_colors[(int)trk.second.detect_class_], 2);
            }
                
        
        }

    }


}