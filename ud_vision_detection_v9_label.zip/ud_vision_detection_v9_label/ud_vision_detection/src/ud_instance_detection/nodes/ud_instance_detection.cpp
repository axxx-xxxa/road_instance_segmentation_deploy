#include "netWrap.hpp"

int main(int argc, char** argv)
{
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(4, &cpuset);
    CPU_SET(5, &cpuset);
    // CPU_SET(6, &cpuset);
    pthread_setaffinity_np(pthread_self(), sizeof(cpu_set_t), &cpuset);
    ros::init(argc, argv, "ud_instance_detection");
    InstanceModel Model;
    Model.init();
    Model.logout();
    Model.warmup();
    Model.infer_from_source();
    ros::spin();
    return 0;
}
