#pragma once

// system
#include "chrono"

// opencv
#include "opencv2/opencv.hpp"

// ros
#include "ros/ros.h"
#include "rosbag/bag.h"
#include "rosbag/view.h"
#include "rosbag/player.h"

// zmq
#include <zmq.hpp>
#include "ros_proto/udImage.pb.h"

// #include "ros_proto/udImage.pb.h"
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>

// msgs
#include <autoware_msgs/DetectedObjectArray.h>

// conqueue
#include <mutex>
#include <condition_variable>
#include <deque>
#include <queue>
#include <memory>

// thread
#include <thread> 

// mutex
#include <mutex>

// assert
#include <assert.h>

#include <json.hpp>

#include <sys/stat.h>


static char const *DIRECTION[] ={
   "front", "left", "right", "back"};

const std::vector<std::string> CLASS_NAMES = {
    "curb",         "person",    "car",           "bicycle",    "free_object",     "lane_marking",           "traffic_sign",
    "truck",        "zebra_crossing"};

const std::vector<std::vector<unsigned int>> COLORS = {
    {0, 114, 189},   {217, 83, 25},   {237, 177, 32},  {126, 47, 142},  {119, 172, 48},  {77, 190, 238},
    {162, 20, 47},   {76, 76, 76},    {153, 153, 153}, {255, 0, 0},     {255, 128, 0},   {191, 191, 0},
    {0, 255, 0},     {0, 0, 255},     {170, 0, 255},   {85, 85, 0},     {85, 170, 0},    {85, 255, 0},
    {170, 85, 0},    {170, 170, 0},   {170, 255, 0},   {255, 85, 0},    {255, 170, 0},   {255, 255, 0},
    {0, 85, 128},    {0, 170, 128},   {0, 255, 128},   {85, 0, 128},    {85, 85, 128},   {85, 170, 128},
    {85, 255, 128},  {170, 0, 128},   {170, 85, 128},  {170, 170, 128}, {170, 255, 128}, {255, 0, 128},
    {255, 85, 128},  {255, 170, 128}, {255, 255, 128}, {0, 85, 255},    {0, 170, 255},   {0, 255, 255},
    {85, 0, 255},    {85, 85, 255},   {85, 170, 255},  {85, 255, 255},  {170, 0, 255},   {170, 85, 255},
    {170, 170, 255}, {170, 255, 255}, {255, 0, 255},   {255, 85, 255},  {255, 170, 255}, {85, 0, 0},
    {128, 0, 0},     {170, 0, 0},     {212, 0, 0},     {255, 0, 0},     {0, 43, 0},      {0, 85, 0},
    {0, 128, 0},     {0, 170, 0},     {0, 212, 0},     {0, 255, 0},     {0, 0, 43},      {0, 0, 85},
    {0, 0, 128},     {0, 0, 170},     {0, 0, 212},     {0, 0, 255},     {0, 0, 0},       {36, 36, 36},
    {73, 73, 73},    {109, 109, 109}, {146, 146, 146}, {182, 182, 182}, {219, 219, 219}, {0, 114, 189},
    {80, 183, 189},  {128, 128, 0}};

const std::vector<std::vector<unsigned int>> MASK_COLORS = {
    {255, 56, 56},  {255, 157, 151}, {255, 112, 31}, {255, 178, 29}, {207, 210, 49},  {0, 255, 0}, {146, 204, 23},
    {61, 219, 134}, {26, 147, 52},   {0, 212, 187},  {44, 153, 168}, {0, 194, 255},   {52, 69, 147}, {100, 115, 255},
    {0, 24, 236},   {132, 56, 255},  {82, 0, 133},   {203, 56, 255}, {255, 149, 200}, {255, 55, 199}};


inline bool folderExists(const std::string& folderPath) {
    struct stat info;
    return stat(folderPath.c_str(), &info) == 0 && S_ISDIR(info.st_mode);
}

inline bool createFolder(const std::string& folderPath) {
    if (mkdir(folderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH) == 0) {
        return true;
    } else {
        return false;
    }
}

inline void mkdirs(std::string path)
{
    if (folderExists(path)) {
    } else {
        if (!createFolder(path)) std::cerr << "创建文件夹时出错" << std::endl;
    }
}

class Timer
{
public:
    void tic() { if (stimes.empty()) stimes.push_back(std::chrono::high_resolution_clock::now());}
    void toc(std::string node="")
    {
        assert(stimes.begin() != stimes.end());

        std::chrono::system_clock::time_point endtime = std::chrono::high_resolution_clock::now();
        std::chrono::system_clock::time_point starttime = stimes.back();
        stimes.pop_back();

        std::chrono::duration<double> elapsed_seconds = endtime - starttime;
        if(!node.empty()) printf("%s cost %fms\n", node.c_str(), elapsed_seconds.count()*1000);
    }
    void tic_fps() { if (ftimes.empty()) ftimes.push_back(std::chrono::high_resolution_clock::now());}
    void toc_fps(int& count, int chn)
    {
        
        std::chrono::system_clock::time_point endtime = std::chrono::high_resolution_clock::now();
        std::chrono::system_clock::time_point starttime = ftimes.back();
        std::chrono::duration<double> elapsed_seconds = endtime - starttime;
        if (elapsed_seconds.count() > 1) {
            ftimes.pop_back();
            printf("[FPS][CHN%d] 1s has processed %d \n", chn, count);
            count = 0;
        }else count++;

    }
private:
    std::vector<std::chrono::system_clock::time_point> stimes;
    std::vector<std::chrono::system_clock::time_point> ftimes;
};


template<typename DATATYPE, typename SEQUENCE = std::deque<DATATYPE>>
class ConcurrenceQueue {
public:
    ConcurrenceQueue() = default;
    ~ConcurrenceQueue() = default;
    ConcurrenceQueue & operator= (const ConcurrenceQueue &) = delete;
    /*
    ConcurrenceQueue(const ConcurrenceQueue & other) {
        std::lock_guard<std::mutex> lg(other.m_mutex);
        m_data = other.m_data;
    }
    ConcurrenceQueue(ConcurrenceQueue &&) = delete;
    */
    bool empty() const {
        std::lock_guard<std::mutex> lg(m_mutex);
        return m_data.empty();
    }
    int size(){
        std::lock_guard<std::mutex>lg(m_mutex);
        return m_data.size();
    }
    int push(const DATATYPE & data) {
        std::lock_guard<std::mutex> lg(m_mutex);
        if(m_data.size()>maxSize)
            return 0;
        m_data.push(data);
        m_cond.notify_one();
        return m_data.size();
    }
    /*
    void push(DATATYPE && data) {
        std::lock_guard<std::mutex> lg(m_mutex);
        m_data.push(std::move(data));
        m_cond.notify_one();
    }*/
    std::shared_ptr<DATATYPE> tryPop() {  // 非阻塞
        std::lock_guard<std::mutex> lg(m_mutex);
        if (m_data.empty()) return {};

        auto res = std::make_shared<DATATYPE>(m_data.front());
        m_data.pop();
        return res;
    }
    
    std::shared_ptr<DATATYPE> pop() {  // 阻塞
        std::unique_lock<std::mutex> lg(m_mutex);
        m_cond.wait(lg, [this] { return !m_data.empty(); });

        auto res = std::make_shared<DATATYPE>(std::move(m_data.front()));
        m_data.pop();
        return res;
    }
    std::shared_ptr<DATATYPE> pop(int sec) {  // 带超时的阻塞
        std::unique_lock<std::mutex> lg(m_mutex);

        bool notempty = m_cond.wait_for(lg, std::chrono::seconds(sec),[this] { return !m_data.empty(); });
        if(!notempty)//if(cs == std::cv_status::timeout || m_data.empty()) 
            return {};

        auto res = std::make_shared<DATATYPE>(std::move(m_data.front()));
        m_data.pop();
        return res;
    }
/*
    std::move唯一的功能是将一个左值强制转化为右值引用，继而可以通过右值引用使用该值，以用于移动语义。
    从实现上讲，std::move基本等同于一个类型转换：static_cast<T&&>(lvalue);
    C++ 标准库使用比如vector::push_back 等这类函数时,会对参数的对象进行复制,连数据也会复制.
    这就会造成对象内存的额外创建, 本来原意是想把参数push_back进去就行了,通过std::move，可以避免不必要的拷贝操作。
*/
private:
    int maxSize=10;
    std::queue<DATATYPE, SEQUENCE> m_data;
    mutable std::mutex m_mutex;
    std::condition_variable m_cond;
};


// utils here
inline int GetType(std::string type)
{
    int ret = -1;
    if (!type.compare("mono8")) ret = CV_8UC1;  else
    if (!type.compare("8UC2" )) ret = CV_8UC2;  else
    if (!type.compare("bgr8" )) ret = CV_8UC3;  else
    if (!type.compare("8UC4" )) ret = CV_8UC4;  else
    if (!type.compare("8SC1" )) ret = CV_8SC1;  else
    if (!type.compare("8SC2" )) ret = CV_8SC2;  else
    if (!type.compare("8SC3" )) ret = CV_8SC3;  else
    if (!type.compare("8SC4" )) ret = CV_8SC4;  else
    if (!type.compare("16UC1")) ret = CV_16UC1; else
    if (!type.compare("16UC2")) ret = CV_16UC2; else
    if (!type.compare("16UC3")) ret = CV_16UC3; else
    if (!type.compare("16UC4")) ret = CV_16UC4; else
    if (!type.compare("16SC1")) ret = CV_16SC1; else
    if (!type.compare("16SC2")) ret = CV_16SC2; else
    if (!type.compare("16SC3")) ret = CV_16SC3; else
    if (!type.compare("16SC4")) ret = CV_16SC4; else
    if (!type.compare("32SC1")) ret = CV_32SC1; else
    if (!type.compare("32SC2")) ret = CV_32SC2; else
    if (!type.compare("32SC3")) ret = CV_32SC3; else
    if (!type.compare("32SC4")) ret = CV_32SC4; else
    if (!type.compare("32FC1")) ret = CV_32FC1; else
    if (!type.compare("32FC2")) ret = CV_32FC2; else
    if (!type.compare("32FC3")) ret = CV_32FC3; else
    if (!type.compare("32FC4")) ret = CV_32FC4; else
    if (!type.compare("64FC1")) ret = CV_64FC1; else
    if (!type.compare("64FC2")) ret = CV_64FC2; else
    if (!type.compare("64FC3")) ret = CV_64FC3; else
    if (!type.compare("64FC4")) ret = CV_64FC4; else;
    return ret;
}

inline std::string GetType(int type)
{
    std::string ret = "";
    if (type == CV_8UC1 ) ret = "mono8"; else
    if (type == CV_8UC2 ) ret = "8UC2" ; else
    if (type == CV_8UC3 ) ret = "bgr8" ; else
    if (type == CV_8UC4 ) ret = "8UC4" ; else
    if (type == CV_8SC1 ) ret = "8SC1" ; else
    if (type == CV_8SC2 ) ret = "8SC2" ; else
    if (type == CV_8SC3 ) ret = "8SC3" ; else
    if (type == CV_8SC4 ) ret = "8SC4" ; else
    if (type == CV_16UC1) ret = "16UC1"; else
    if (type == CV_16UC2) ret = "16UC2"; else
    if (type == CV_16UC3) ret = "16UC3"; else
    if (type == CV_16UC4) ret = "16UC4"; else
    if (type == CV_16SC1) ret = "16SC1"; else
    if (type == CV_16SC2) ret = "16SC2"; else
    if (type == CV_16SC3) ret = "16SC3"; else
    if (type == CV_16SC4) ret = "16SC4"; else
    if (type == CV_32SC1) ret = "32SC1"; else
    if (type == CV_32SC2) ret = "32SC2"; else
    if (type == CV_32SC3) ret = "32SC3"; else
    if (type == CV_32SC4) ret = "32SC4"; else
    if (type == CV_32FC1) ret = "32FC1"; else
    if (type == CV_32FC2) ret = "32FC2"; else
    if (type == CV_32FC3) ret = "32FC3"; else
    if (type == CV_32FC4) ret = "32FC4"; else
    if (type == CV_64FC1) ret = "64FC1"; else
    if (type == CV_64FC2) ret = "64FC2"; else
    if (type == CV_64FC3) ret = "64FC3"; else
    if (type == CV_64FC4) ret = "64FC4"; else;
    return std::move(ret);
}

inline int PixelSize(int type)
{
    int ret = 0;
    if (type == CV_8UC1 ) ret =  1; else
    if (type == CV_8UC2 ) ret =  2; else
    if (type == CV_8UC3 ) ret =  3; else
    if (type == CV_8UC4 ) ret =  4; else
    if (type == CV_8SC1 ) ret =  1; else
    if (type == CV_8SC2 ) ret =  2; else
    if (type == CV_8SC3 ) ret =  3; else
    if (type == CV_8SC4 ) ret =  4; else
    if (type == CV_16UC1) ret =  2; else
    if (type == CV_16UC2) ret =  4; else
    if (type == CV_16UC3) ret =  6; else
    if (type == CV_16UC4) ret =  8; else
    if (type == CV_16SC1) ret =  2; else
    if (type == CV_16SC2) ret =  4; else
    if (type == CV_16SC3) ret =  6; else
    if (type == CV_16SC4) ret =  8; else
    if (type == CV_32SC1) ret =  4; else
    if (type == CV_32SC2) ret =  8; else
    if (type == CV_32SC3) ret = 12; else
    if (type == CV_32SC4) ret = 16; else
    if (type == CV_32FC1) ret =  4; else
    if (type == CV_32FC2) ret =  8; else
    if (type == CV_32FC3) ret = 12; else
    if (type == CV_32FC4) ret = 16; else
    if (type == CV_64FC1) ret =  8; else
    if (type == CV_64FC2) ret = 16; else
    if (type == CV_64FC3) ret = 24; else
    if (type == CV_64FC4) ret = 32; else;
    return ret;
}




inline std::map<int, std::string> get_cls_label()
{
    return {
        // {0, "0"},
        // {1, "1"},
        // {2, "2"},
        // {3, "3"},
        // {4, "4"},
        // {5, "5"},
        // {6, "6"},
        // {7, "7"},
        // {8, "8"}
        {0, "curb"},
        {1, "person"},
        {2, "car"},
        {3, "bicycle"},
        {4, "free_object"},
        {5, "lane_marking"},
        {6, "traffic_sign"},
        {7, "truck"},
        {8, "zebra_crossing"},
        {9, "waiting_object"},
        {10, "obstacle"},
    };
}

inline std::vector<cv::Scalar> get_cls_color(const std::map<int, std::string> class_labels)
{
    std::vector<cv::Scalar> class_colors;
    class_colors.resize(class_labels.size());
    srand((int) time(nullptr));
    for (cv::Scalar &class_color: class_colors)
        class_color = cv::Scalar(rand() % 255, rand() % 255, rand() % 255);
    return class_colors;
}

inline std::vector<cv::Scalar> get_det_color()
{
    std::vector<cv::Scalar> detect_colors;
    detect_colors.resize(100);
    srand((int) time(nullptr));
    for (cv::Scalar &detect_color: detect_colors)
        detect_color = cv::Scalar(rand() % 255, rand() % 255, rand() % 255,  0);
    return detect_colors;
}



#ifdef USE_COMPRESSED_IMAGE
inline cv::Mat msg2cvmat(sensor_msgs::CompressedImageConstPtr &msg_in){
    cv::Mat img = cv::imdecode(cv::Mat(msg_in->data), cv::IMREAD_COLOR);
    return img;
}
#else
inline cv::Mat msg2cvmat(sensor_msgs::ImageConstPtr &msg_in){
    return cv::Mat(msg_in->height, msg_in->width, CV_8UC3, const_cast<uint8_t*>(&msg_in->data[0]), msg_in->step);
}
#endif

inline std::shared_ptr<sensor_msgs::Image> cvmat2msg(const cv::Mat &img) {
    size_t sizez = img.total() * img.elemSize();
    auto msg_out = std::make_shared<sensor_msgs::Image>();
    msg_out->header.frame_id = "";
    msg_out->header.stamp    = ros::Time::now();
    msg_out->header.seq      = 0;
    msg_out->height          = img.rows;
    msg_out->width           = img.cols;
    msg_out->is_bigendian    = 0;
    msg_out->encoding        = GetType(img.type());
    msg_out->step            = img.cols * PixelSize(img.type());
    msg_out->data.resize(msg_out->step * img.rows);
    memcpy(msg_out->data.data(), img.ptr(), msg_out->data.size());
    return msg_out;
}

inline sensor_msgs::Image cvmat2msg_(const cv::Mat &img) {
    size_t sizez = img.total() * img.elemSize();
    sensor_msgs::Image msg_out;
    msg_out.header.frame_id = "";
    msg_out.header.stamp    = ros::Time::now();
    msg_out.header.seq      = 0;
    msg_out.height          = img.rows;
    msg_out.width           = img.cols;
    msg_out.is_bigendian    = 0;
    msg_out.encoding        = GetType(img.type());
    msg_out.step            = img.cols * PixelSize(img.type());
    msg_out.data.resize(msg_out.step * img.rows);
    memcpy(msg_out.data.data(), img.ptr(), msg_out.data.size());
    return msg_out;
}

inline std::vector<int> ints2intsarray(const std::vector<int>& rangeArray, int h, int w) {
    std::vector<int> result(h * w, 0);  

    for (int i = 0; i < rangeArray.size(); i += 2) {
        int start = rangeArray[i];
        int end = rangeArray[i + 1];
        for (int j = start; j <= end; j++) {
            if (j >= 0 && j < h * w) {
                result[j] = 255;
            }
        }
    }

    return result;
}

inline cv::Mat ints2cvmat(std::vector<int> intArray, int w, int h) {
    cv::Mat mask(h, w, CV_8U, cv::Scalar(0));
    for (int i = 0; i < intArray.size(); i += 2) {
        int start = intArray[i];
        int end = intArray[i + 1];
        for (int value = start; value <= end; value++) {
            if (value >= 0 && value < h * w) {
                int row = value / w;
                int col = value % w;
                mask.at<uchar>(row, col) = 255;
            }
        }
    }
    return mask;
}

inline cv::Mat bools2cvmat(std::vector<unsigned char>& boolArray, int w, int h) {
    cv::Mat mask(h, w, CV_8U, cv::Scalar(0));
    
    // 遍历bool数组并设置mask的像素值
    for (int i = 0; i < h; i++) {
        for (int j = 0; j < w; j++) {
            int index = i * w + j;
            if (index < boolArray.size() && boolArray[index]) {
                mask.at<uchar>(i, j) = 255; // 将1赋值为255
            }
        }
    }
    
    return mask;
}


inline std::vector<bool> cvmat2bools(const cv::Mat& img) {
    std::vector<bool> pixs;
    for(int y = 0; y < img.rows; y++) {
        for(int x = 0; x < img.cols; x++) {
            bool pix = (img.at<uchar>(y,x) == 255);
            pixs.push_back(pix);
        }
    }
    return pixs;
}

inline std::vector<int> cvmat2ints(const cv::Mat& img) {
    std::vector<int> pixs;
    int s = 0;
    int e = 0;
    int idx = 0;
    bool status = false;
    // printf("----------------------------------------------------------------\n");
    for(int y = 0; y < img.rows; y++) {
        for(int x = 0; x < img.cols; x++) {
            // process from 0 - end
            // 0 0 0 255 255 
            // (if 255 and status = false) status = true, s = idx; push s 
            // (if 255 and status = true) status = true;
            // (if 0 and status = true) status = false, e = idx; push e
            // (if 0 and status = false) status = false;

            if(img.at<uchar>(y,x) == 255 && status == false) {
                s = idx; 
                status = true;
                pixs.push_back(s);
                // std::cout<<"[push s ] "<<s<<std::endl;
            }
            if(img.at<uchar>(y,x) == 255 && status == true) {
                status = true;
            }
            if(img.at<uchar>(y,x) == 0 && status == true) {
                status = false;
                e = idx - 1;
                pixs.push_back(e);
                // std::cout<<"[push e ] "<<e<<std::endl;

            }
            if(img.at<uchar>(y,x) == 0 && status == false) {
                status = false;
            }

            idx ++;
        }
    }
    return pixs;
}

inline void saveJson(const autoware_msgs::DetectedObjectArray &in_detections, cv::Mat &out_img, std::string json_root, int chn)
{
    std::map<int, std::string> class_labels{
        {0, "curb"},
        {1, "person"},
        {2, "car"},
        {3, "bicycle"},
        {4, "free_object"},
        {5, "lane_marking"},
        {6, "traffic_sign"},
        {7, "truck"},
        {8, "zebra_crossing"},
        {9, "waiting_object"},
        {10, "obstacle"},
    };
	int points_interval = 20; 
	int mask_w, mask_h, mask_x, mask_y, start, end;
	std::vector<std::vector<cv::Point>> contours;
	std::vector<cv::Vec4i> hierarchy;
	nlohmann::json labelmeData;
	nlohmann::json json_shapes = nlohmann::json::array();
    std::string dire = DIRECTION[chn];
    std::string root = json_root + "/" + dire;
    mkdirs(root);
	std::string image_path = root + "/" + std::to_string(in_detections.header.stamp.toSec()) + ".jpg";
	std::string label_path = root + "/" + std::to_string(in_detections.header.stamp.toSec()) + ".json";
	
    // save label
    int width = 1920;
    int height = 1080;
	for(int i=0; i<in_detections.objects.size(); i++)
	{
		cv::Mat mask = cv::Mat::zeros(cv::Size(width, height), CV_8UC1);
		mask_w = in_detections.objects[i].width;
		mask_h = in_detections.objects[i].height;   
		mask_x = in_detections.objects[i].x;
		mask_y = in_detections.objects[i].y;    
		for(int h = 0; h < int(in_detections.objects[i].int_mask.size()-1); h=h+2)
		{
			start = in_detections.objects[i].int_mask[h];
			end = in_detections.objects[i].int_mask[h+1];   
			for (int l = start; l <= end; l++)
			{
				if (l < mask_w*mask_h && l>=0)
				{
					int k = l/mask_w;
					int j = l%mask_w;   
					if(height<=(k+mask_y) || width<=(j+mask_x)) continue;        
					mask.at<uchar>(k+mask_y, j+mask_x) = 255;     
				}          
			}
		}
		cv::findContours(mask, contours, hierarchy, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_NONE, cv::Point());
		for (size_t jj = 0; jj < contours.size(); jj ++)
		{
			nlohmann::json json_object;
			nlohmann::json json_points = nlohmann::json::array();
			json_object["description"] = "";
			json_object["label"] = in_detections.objects[i].label;
			for (size_t j = 0; j < contours[jj].size(); j = j+points_interval)
			{
				json_points.push_back({contours[jj][j].x, contours[jj][j].y});
			}
			json_object["points"] = json_points;
			json_object["shape_type"] = "polygon";
			json_object["flags"] = 	nlohmann::json::object();
			json_shapes.push_back(json_object);
		}
	}
    labelmeData["version"] = "5.1.1";
    labelmeData["flags"] = nlohmann::json::object();
    labelmeData["shapes"] = json_shapes;
    labelmeData["imagePath"] = std::to_string(in_detections.header.stamp.toSec()) + ".jpg";
    labelmeData["imageData"] = nullptr;
    labelmeData["imageHeight"] = 1080;
    labelmeData["imageWidth"] = 1920;
    std::ofstream output_labelFile(label_path);
    output_labelFile << labelmeData.dump(4);
    output_labelFile.close();
    cv::imwrite(image_path, out_img);
	usleep(5000);
}
