#pragma once


// yolov8
#include "yolov8-seg.hpp" 

// sort
#include "tracker.h"

// utils
#include "utils.hpp"

#define CHN 3
#define SLEEP 0
#define PREPROCESS 1
#define PREPROCESSING 11
#define INFER 2
#define INFERING 22
#define POSTPROCESS 3
#define POSTPROCESSING 33
#define TRACK 4
#define TRACKING 44
#define DRAW 5
#define DRAWING 55
#define FINISHED 6

#define g_running 1
#define SLEEPTIME 1000



static std::map<int, std::string> camera_chn = {{0,"ud_camera5"}, {1,"ud_camera7"}, {2,"ud_camera8"}, {3,"ud_camera6"}};

struct InsData {
  cv::Mat share_mat;
  std_msgs::Header header;
};

class InstanceROS {
public:
  InstanceROS();
  virtual ~InstanceROS(){};

  ros::NodeHandle get_nh() {return nh;}
  ros::Publisher get_pubi() {return infer_puber;}
  ros::Publisher get_pubc() {return object_puber;}
  void tic() {stimes.push_back(std::chrono::high_resolution_clock::now());}
  double toc(std::string node="")
  {
    assert(stimes.begin() != stimes.end());

    std::chrono::system_clock::time_point endtime = std::chrono::high_resolution_clock::now();
    std::chrono::system_clock::time_point starttime = stimes.back();
    stimes.pop_back();

    std::chrono::duration<double> elapsed_seconds = endtime - starttime;
    if(!node.empty()) printf("%s cost %fms\n", node.c_str(), elapsed_seconds.count()*1000);
    return elapsed_seconds.count();
  }

  // @brief tic toc: time print tool

protected:

  // stimes
  int timer_frames = 0;
  std::chrono::system_clock::time_point  st_time;
  std::chrono::system_clock::time_point  ct_time;
  std::vector<std::chrono::system_clock::time_point> stimes;

  // instance model params
  int verbose = 0;
  int seg_size;
  int img_size;
  bool userosbag = false;
  bool usezmq = false;
  std::string modelpath, modelname, modeltype, ObjPubtopic, ImgPubtopic, frameid, calib_root, calib_file, json_root;
  std::string subtopic, subtopic1, subtopic2, subtopic3, subtopic4;
  std::vector<std::string> subtopics;
  // ST and INS shared params

  InsParams Iparams;

  
  inline InsParams set_seg_param()
  {
    InsParams Iparams;
    Iparams.topk           = 100;
    Iparams.seg_h          = seg_size;
    Iparams.seg_w          = seg_size;
    Iparams.seg_channels   = 32;
    Iparams.score_thres    = 0.40f;
    Iparams.iou_thres      = 0.65f;
    Iparams.size           = cv::Size{img_size, img_size};
    Iparams.class_labels   = get_cls_label();
    Iparams.class_colors   = get_cls_color(Iparams.class_labels);
    Iparams.detect_colors  = get_det_color();
    Iparams.draw_track     = false;
    return Iparams;
  }

  ros::Publisher infer_pubers[CHN];
  ros::Publisher object_pubers[CHN];

private:

  ros::Publisher infer_puber;
  ros::Publisher object_puber;
  ros::NodeHandle nh;

};

/*  
class Speed_Tracker : public Tracker
{
public:
  inline void update_status(sensor_msgs::ImageConstPtr &msg_in)
  { 
    detect_objs = {};
    tracked_objs = {};
    prev_detection = {};
    input_header = msg_in->header;
    input_header.frame_id = msg_in->header.frame_id;
    detect_objs.header.stamp = input_header.stamp;
    detect_objs.header.frame_id = input_header.frame_id;
    if (speed_estimation)
    {
      tracked_objs.header.stamp = input_header.stamp;
      tracked_objs.header.frame_id = input_header.frame_id;
    }
    
  }
  void run(InsParams Iparams, std::vector<Object>& objs, cv::Mat& share_mat);
  
  autoware_msgs::DetectedObjectArray detect_objs;

private:

  Tracker sort;

  std::map<int, Track> tracks;
  std_msgs::Header input_header;
  
  autoware_msgs::DetectedObjectArray tracked_objs;
  autoware_msgs::DetectedObjectArray prev_detection;

  int speed_ = 0;  // init speed
  float curr_measure_x = 0.0;
  float curr_measure_y = 0.0;
  float prev_measure_x = 0.0;
  float prev_measure_y = 0.0;
  bool speed_estimation = false;

  void trk2DetectedObject(InsParams Iparams, const std::pair<const int, Track> trk, autoware_msgs::DetectedObject &detect_obj);
  inline void speed_back_zero()
  {
    speed_ = 0;  // init speed
    curr_measure_x = 0.0;
    curr_measure_y = 0.0;
    prev_measure_x = 0.0;
    prev_measure_y = 0.0;
  }
};
*/


class InstanceModel : public InstanceROS
{
public:
    InstanceModel();
    ~InstanceModel();

    void init();
    void logout();
    void release();
    void warmup();
    void infer_from_source();

    // @brief init : init
    // @brief logout : logout model info
    // @brief release : release
    // @brief warmup : warmup
    // @brief callback_from_topic : TOPIC callback
    // @brief infer_from_topic : 调用callback
    // @brief infer_type_RGBIMG : inference内部二级接口

private:

  // buffer
  std::vector<ConcurrenceQueue<InsData>> data_queues{CHN};

  // zmq thread
  std::thread zmq_threads[CHN];

  // ros thread
  ros::Subscriber img_subs[CHN];

  // inference thread
  std::thread infer_threads[CHN];

  // yoloseg handle and func
  std::unique_ptr<YOLOv8_seg> Inets[CHN];
  
  // zmq
  void callback_from_zmq(int chn);
  void Msgcalback(const sensor_msgs::udImage &q_image, int chn);

  // rostopic
#ifdef USE_COMPRESSED_IMAGE
  void callback_from_topic(const sensor_msgs::CompressedImageConstPtr &msg, int chn);
  sensor_msgs::CompressedImage::ConstPtr msg_in[CHN];
#else
  void callback_from_topic(const sensor_msgs::ImageConstPtr &msg, int chn);
  sensor_msgs::Image::ConstPtr msg_in[CHN];
#endif
  void infer_type_RGBIMG(int chn);
  void track(int chn, InsData& data, InsParams Iparams, std::vector<Object>& objs, autoware_msgs::DetectedObjectArray& detect_objs,  Tracker sort);

  // mutex
  double g_curt_timer[CHN] = {0};
  double g_last_timer[CHN] = {0};
  int g_status[CHN] = {0};
  int g_counter[CHN] = {0};
  std::mutex m_mutex;


  bool check_status(int chn, int status) {
    m_mutex.lock();
    if(status == FINISHED) {
      g_status[chn] = FINISHED;
      g_counter[chn]++;
      m_mutex.unlock();
    }else{
      bool ret = true;
      bool allsame = true;
      g_status[chn] = status;
  #ifdef THREADS_DEBUGER
      log_status(chn, "before");
  #endif
      for (int i = 0; i < CHN; i++) {
        if (i == chn) continue;
        if (g_status[i] == PREPROCESSING && g_status[chn] == PREPROCESS) ret = false; 
        if (g_status[i] == INFERING && g_status[chn] == INFER) ret = false; 
        // if (g_status[i] == POSTPROCESSING && g_status[chn] == POSTPROCESS) ret = false; 
        if (g_status[i] == DRAWING && g_status[chn] == DRAW) ret = false; 
        if (g_counter[chn] - g_counter[i] > 1) ret = false;
      }
      if(ret) {
        if (g_status[chn] == PREPROCESS) g_status[chn] = PREPROCESSING;
        if (g_status[chn] == INFER) g_status[chn] = INFERING;
        if (g_status[chn] == POSTPROCESS) g_status[chn] = POSTPROCESSING;
        if (g_status[chn] == DRAW) g_status[chn] = DRAWING;
      }
  #ifdef THREADS_DEBUGER
      log_status(chn, "after");
  #endif
      m_mutex.unlock();
      return ret;
    }
  }


  void log_status(int chn, std::string node) {
    printf("[%s][CHN %d][STATUS] ", node.c_str(), chn);
    for (int i = 0; i < CHN; i++) {
      printf(" chn[%d]", i);
      if (g_status[i] == SLEEP)         printf(" SLEEP");
      if (g_status[i] == PREPROCESS)    printf(" PREPROCESS");
      if (g_status[i] == PREPROCESSING) printf(" PREPROCESSING");
      if (g_status[i] == INFER)         printf(" INFER");
      if (g_status[i] == INFERING)      printf(" INFERING");
      if (g_status[i] == POSTPROCESS)   printf(" POSTPROCESS");
      if (g_status[i] == POSTPROCESSING)printf(" POSTPROCESSING");
      if (g_status[i] == TRACK)         printf(" TRACK");
      if (g_status[i] == DRAW)          printf(" DRAW");
      if (g_status[i] == DRAWING)       printf(" DRAWING");
    }
    printf("\n");
  }

  void tic_counter() { if (ftimes.empty()) ftimes.push_back(std::chrono::high_resolution_clock::now());}
  void toc_counter()
  {
      std::chrono::system_clock::time_point endtime = std::chrono::high_resolution_clock::now();
      std::chrono::system_clock::time_point starttime = ftimes.back();
      std::chrono::duration<double> elapsed_seconds = endtime - starttime;
      if (elapsed_seconds.count() > 10) {
        g_counter[0] = 0;
        g_counter[1] = 0;
        g_counter[2] = 0;
        g_counter[3] = 0;
        ftimes.pop_back();
        tic_counter();
      }
  }

private:
    std::vector<std::chrono::system_clock::time_point> stimes;
    std::vector<std::chrono::system_clock::time_point> ftimes;
};







